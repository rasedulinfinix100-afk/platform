Upload the seven .webp files to public/images/tickets/ in the GitHub repository.
Replace app/Ticket/Chart/page.tsx with page.tsx and app/Ticket/chart.css with chart.css.
Ticket order: 10, 20, 50, 100, 200, 500, 1000 BDT.
Countdown values are placeholders until the Supabase draw schedule is connected.
